<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hi">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="20"/>
        <location filename="../mainwindow.cpp" line="153"/>
        <source>Custom Toolbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>इस अनुप्रयोग के बारे में</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>बारे में...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="73"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="89"/>
        <source>Customize launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="92"/>
        <source>Edit</source>
        <translation>संपादन</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="99"/>
        <source>Alt+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="163"/>
        <source>Help</source>
        <translation>सहायता</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="170"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="183"/>
        <source>Close application</source>
        <translation>अनुप्रयोग बंद करें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="186"/>
        <source>Close</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="193"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="308"/>
        <source>This is a custom launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="324"/>
        <source>Show this dialog at start up</source>
        <translation>आरंभ होने पर यह विंडो दिखाएँ</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="346"/>
        <source>search</source>
        <translation>खोज</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Open List File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>List Files (*.list)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="269"/>
        <location filename="../mainwindow.cpp" line="518"/>
        <location filename="../mainwindow.cpp" line="650"/>
        <source>File Open Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="269"/>
        <source>Could not open file, do you want to try again?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>Could not open file: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>Application will close.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="601"/>
        <source>About %1</source>
        <translation>%1 के बारे में</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="602"/>
        <source>Version: </source>
        <translation>संस्करण :</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="607"/>
        <source>Copyright (c) MX Linux</source>
        <translation>कॉपीराइट (c) एमएक्स लिनक्स</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="608"/>
        <source>%1 License</source>
        <translation>%1 लाइसेंस</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="615"/>
        <source>%1 Help</source>
        <translation>%1 सहायता</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="650"/>
        <source>Could not write file: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>License</source>
        <translation>लाइसेंस</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="52"/>
        <location filename="../about.cpp" line="62"/>
        <source>Changelog</source>
        <translation>बदलाव सूची</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>Cancel</source>
        <translation>रद्द करें</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="75"/>
        <source>&amp;Close</source>
        <translation>बंद करें (&amp;C)</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="71"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="74"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="77"/>
        <source>Full path and name of the .list file you want to load to set up the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="87"/>
        <source>Error</source>
        <translation>त्रुटि</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="88"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>प्रतीत होता है कि आप रुट के रूप में लॉगिन हैं, प्रोग्राम उपयोग करने हेतु लॉगआउट कर सामान्य उपयोक्ता के रूप में लॉगिन करें।</translation>
    </message>
</context>
</TS>
