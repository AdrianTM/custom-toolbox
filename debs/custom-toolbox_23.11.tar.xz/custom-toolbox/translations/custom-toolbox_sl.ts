<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sl">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="20"/>
        <location filename="../mainwindow.cpp" line="137"/>
        <source>Custom Toolbox</source>
        <translation>Prilagojena orodjarna</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="63"/>
        <source>About this application</source>
        <translation>O tem programu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="66"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="73"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="89"/>
        <source>Customize launcher</source>
        <translation>Prilagodi zaganjalnik</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="92"/>
        <source>Edit</source>
        <translation>Uredi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="99"/>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="163"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="170"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="183"/>
        <source>Close application</source>
        <translation>Zapri program</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="186"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="193"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="308"/>
        <source>This is a custom launcher</source>
        <translation>To je zaganjalnik po meri</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="324"/>
        <source>Show this dialog at start up</source>
        <translation>Ob zagonu prikaži ta dialog</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="346"/>
        <source>search</source>
        <translation>iskanje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="244"/>
        <source>Open List File</source>
        <translation>Odpri zadnjo datoteko</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="244"/>
        <source>List Files (*.list)</source>
        <translation>Datoteke seznamov (*.list)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="249"/>
        <location filename="../mainwindow.cpp" line="476"/>
        <location filename="../mainwindow.cpp" line="555"/>
        <source>File Open Error</source>
        <translation>Napaka pri odpiranju datoteke</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="249"/>
        <source>Could not open file, do you want to try again?</source>
        <translation>Datoteke ni bilo mogoče odpreti. Poskusim znova?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="477"/>
        <source>Could not open file: </source>
        <translation>Datoteke ni bilo mogoče odpreti:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="477"/>
        <source>Application will close.</source>
        <translation>Program se bo zaprl.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="506"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>Version: </source>
        <translation>Različica:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="509"/>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation>Orodjarna je orodje za ustvarjanje zaganjalnikov po meri</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="512"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>%1 License</source>
        <translation>%1 licenca</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="520"/>
        <source>%1 Help</source>
        <translation>%1 pomoč</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="555"/>
        <source>Could not write file: </source>
        <translation>Datoteke ni bilo mogoče zapisati:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="48"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="49"/>
        <location filename="../about.cpp" line="59"/>
        <source>Changelog</source>
        <translation>Dnevnik sprememb</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="50"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="72"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="67"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Ta program omogoča ustvarjanje zaganjalnikov po meri: slkupek gumbov/ikon</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="70"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Ne prikaži izbirnika &apos;ob zagonu prikaži ta dialog&apos;</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="73"/>
        <source>Full path and name of the .list file you want to load to set up the application</source>
        <translation>Celotna pot in ime .list datoteke, ki jo želite naložiti za nastavitev aplikacije</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="83"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="84"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Prijavljeni ste kot korenski (root) uporabnik. Odjavite se in se ponovno prijavite kot običajen uporabnik, če želite uporabljati ta program.</translation>
    </message>
</context>
</TS>