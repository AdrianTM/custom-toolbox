<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
<context>
    <name>LauncherCard</name>
    <message>
        <location filename="../qml/components/LauncherCard.qml" line="70"/>
        <source>Open this launcher</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="43"/>
        <source>Configuration error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="131"/>
        <source>Search launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="154"/>
        <source>Search launchers and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="166"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="213"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="249"/>
        <location filename="../qml/Main.qml" line="459"/>
        <source>Launch at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="256"/>
        <source>Open this toolbox automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="266"/>
        <location filename="../qml/Main.qml" line="468"/>
        <source>Launch this toolbox at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="332"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="334"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="341"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="342"/>
        <source>Choose a launcher to start an application or task</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="349"/>
        <source>%n launcher(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="364"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="373"/>
        <source>Use condensed launcher view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="375"/>
        <source>Show more launchers at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="447"/>
        <source>No launchers found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="498"/>
        <source>About %1</source>
        <translation type="unfinished">%1 névjegye</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="531"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="537"/>
        <source>Custom Toolbox creates focused collections of application launchers and system tasks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="545"/>
        <source>License</source>
        <translation type="unfinished">Licenc</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="554"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/launchermodel.h" line="99"/>
        <source>Custom Toolbox</source>
        <translation>Saját eszköztár</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">Az alkalmazásról</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="182"/>
        <source>About...</source>
        <translation>Névjegy...</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation type="vanished">Alt+A</translation>
    </message>
    <message>
        <source>Customize launcher</source>
        <translation type="vanished">Indító testreszabása</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="473"/>
        <source>Edit</source>
        <translation>Szerkesztés</translation>
    </message>
    <message>
        <source>Alt+E</source>
        <translation type="vanished">Alt+E</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="174"/>
        <location filename="../src/launchermodel.cpp" line="727"/>
        <source>Help</source>
        <translation>Súgó</translation>
    </message>
    <message>
        <source>Alt+H</source>
        <translation type="vanished">Alt+H</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">Alkalmazás bezárása</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="481"/>
        <source>Close</source>
        <translation>Bezárás</translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation type="vanished">Alt+C</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.h" line="100"/>
        <source>This is a custom launcher</source>
        <translation>Ez egy egyéni indító</translation>
    </message>
    <message>
        <source>Show this dialog at start up</source>
        <translation type="vanished">Ablak megjelenítése indításkor</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">keresés</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="553"/>
        <location filename="../src/launchermodel.cpp" line="560"/>
        <location filename="../src/launchermodel.cpp" line="582"/>
        <location filename="../src/launchermodel.cpp" line="611"/>
        <location filename="../src/launchermodel.cpp" line="623"/>
        <source>Execution Error</source>
        <translation>Végrehajtási hiba</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="514"/>
        <source>Command is empty. Cannot execute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="553"/>
        <source>The selected launcher is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="611"/>
        <source>Failed to start command: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="623"/>
        <source>Failed to execute command: %1</source>
        <translation>A parancs végrehajtása sikertelen: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="582"/>
        <source>Failed to start program: %1</source>
        <translation>A program indítása sikertelen: %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="414"/>
        <location filename="../src/launchermodel.cpp" line="858"/>
        <location filename="../src/main.cpp" line="67"/>
        <source>File Open Error</source>
        <translation>Hiba a fájl megnyitásakor</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="401"/>
        <location filename="../src/main.cpp" line="156"/>
        <source>File Not Found</source>
        <translation>A fájl nem található</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="535"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="401"/>
        <location filename="../src/main.cpp" line="157"/>
        <source>The file %1 does not exist.</source>
        <translation>A fájl nem létezik: %1.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="414"/>
        <source>Could not open file: </source>
        <translation>Fájl megnyitása nem sikerült:</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="420"/>
        <location filename="../src/launchermodel.cpp" line="449"/>
        <source>Parse Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="420"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="426"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="449"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="568"/>
        <source>Launcher already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="569"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="727"/>
        <location filename="../src/launchermodel.cpp" line="734"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="781"/>
        <source>Refusing to overwrite a non-Custom Toolbox autostart file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="887"/>
        <source>Could not reload the configuration. The previous configuration is still in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="vanished">Verzió:</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="vanished">%1 névjegye</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="849"/>
        <source>Could not create directory: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="713"/>
        <location filename="../src/launchermodel.cpp" line="719"/>
        <location filename="../src/launchermodel.cpp" line="734"/>
        <source>Error</source>
        <translation>Hiba</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="659"/>
        <source>Editor command is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="719"/>
        <source>Failed to launch the editor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="680"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation type="vanished">Az Saját eszköztár egy segédeszköz saját indító létrehozására</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">Copyright (c) MX Linux</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">%1 licenc</translation>
    </message>
    <message>
        <source>%1 Help</source>
        <translation type="vanished">%1 súgó</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="800"/>
        <location filename="../src/launchermodel.cpp" line="811"/>
        <source>Could not write file: %1</source>
        <translation>A fájl írása nem sikerült: %1</translation>
    </message>
    <message>
        <source>File Removal Error</source>
        <translation type="vanished">Hiba a fájl eltávolításakor</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="854"/>
        <source>Could not remove file: %1</source>
        <translation>A fájl eltávolítása nem sikerült: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="56"/>
        <source>Open List File</source>
        <translation>Listafájl megnyitása</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="58"/>
        <source>List Files (*.list)</source>
        <translation>Lista fájlok (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>A fájl megnyitása nem sikerült. Megpróbálja ismét?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">Licenc</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">Változások listája</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Mégsem</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;Bezárás</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="95"/>
        <source>Custom Toolbox</source>
        <translation type="unfinished">Saját eszköztár</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Ez az alkalmazás saját indítók létrehozására használható: gombok/ikonok egy dobozban</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Ne jelenjen meg a &apos;Jelenjen meg ez az ablak indításkor&apos; opció</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Error</source>
        <translation>Hiba</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Úgy tűnik, hogy root felhasználóként van bejelentkezve. Jelentkezzen ki és jelentkezzen be egyszerű felhasználóként a program használatához.</translation>
    </message>
</context>
</TS>
