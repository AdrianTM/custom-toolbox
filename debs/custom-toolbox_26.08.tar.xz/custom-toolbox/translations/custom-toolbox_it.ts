<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it">
<context>
    <name>LauncherCard</name>
    <message>
        <location filename="../qml/components/LauncherCard.qml" line="69"/>
        <source>Open this launcher</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="42"/>
        <source>Configuration error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="129"/>
        <source>Search launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="152"/>
        <source>Search launchers and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="164"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="211"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="247"/>
        <location filename="../qml/Main.qml" line="401"/>
        <source>Launch at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="254"/>
        <source>Open this toolbox automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="264"/>
        <location filename="../qml/Main.qml" line="410"/>
        <source>Launch this toolbox at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="313"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="315"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="322"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="323"/>
        <source>Choose a launcher to start an application or task</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="330"/>
        <source>%n launcher(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="389"/>
        <source>No launchers found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="440"/>
        <source>About %1</source>
        <translation type="unfinished">Circa %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="461"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="467"/>
        <source>Custom Toolbox creates focused collections of application launchers and system tasks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="475"/>
        <source>License</source>
        <translation type="unfinished">Licenza</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="484"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/launchermodel.h" line="99"/>
        <source>Custom Toolbox</source>
        <translation>Cassetto degli strumenti personalizzato</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">Informazioni su questa applicazione</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="180"/>
        <source>About...</source>
        <translation>Info...</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation type="vanished">Alt+A</translation>
    </message>
    <message>
        <source>Customize launcher</source>
        <translation type="vanished">Personalizza lanciatore</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="415"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <source>Alt+E</source>
        <translation type="vanished">Alt+E</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="172"/>
        <location filename="../src/launchermodel.cpp" line="701"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <source>Alt+H</source>
        <translation type="vanished">Alt+H</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">Chiudi l&apos;applicazione</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="423"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation type="vanished">Alt+C</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.h" line="100"/>
        <source>This is a custom launcher</source>
        <translation>Questo è un lanciatore personalizzato</translation>
    </message>
    <message>
        <source>Show this dialog at start up</source>
        <translation type="vanished">Mostra questa finestra all&apos;avvio</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">cerca</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="553"/>
        <location filename="../src/launchermodel.cpp" line="560"/>
        <location filename="../src/launchermodel.cpp" line="566"/>
        <location filename="../src/launchermodel.cpp" line="586"/>
        <location filename="../src/launchermodel.cpp" line="597"/>
        <source>Execution Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="514"/>
        <source>Command is empty. Cannot execute.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="553"/>
        <source>The selected launcher is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="586"/>
        <source>Failed to start command: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="597"/>
        <source>Failed to execute command: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="566"/>
        <source>Failed to start program: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="67"/>
        <location filename="../src/launchermodel.cpp" line="414"/>
        <location filename="../src/launchermodel.cpp" line="832"/>
        <source>File Open Error</source>
        <translation>Errore apertura file</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="156"/>
        <location filename="../src/launchermodel.cpp" line="401"/>
        <source>File Not Found</source>
        <translation>File non trovato</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="535"/>
        <source>Could not determine the unprivileged user. Refusing to run this launcher as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="157"/>
        <location filename="../src/launchermodel.cpp" line="401"/>
        <source>The file %1 does not exist.</source>
        <translation>Il file %1 non esiste.</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="414"/>
        <source>Could not open file: </source>
        <translation>Non è stato possibile aprire il file:</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="420"/>
        <location filename="../src/launchermodel.cpp" line="449"/>
        <source>Parse Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="420"/>
        <source>The file %1 contains no recognizable launcher entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="426"/>
        <source>All launchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="449"/>
        <source>None of the entries in %1 match an installed application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="701"/>
        <location filename="../src/launchermodel.cpp" line="708"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="755"/>
        <source>Refusing to overwrite a non-Custom Toolbox autostart file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="861"/>
        <source>Could not reload the configuration. The previous configuration is still in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="vanished">Versione:</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation type="vanished">Circa %1</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="823"/>
        <source>Could not create directory: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="687"/>
        <location filename="../src/launchermodel.cpp" line="693"/>
        <location filename="../src/launchermodel.cpp" line="708"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="633"/>
        <source>Editor command is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="693"/>
        <source>Failed to launch the editor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="654"/>
        <source>Could not determine the unprivileged user. Refusing to launch the editor as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Toolbox is a tool used for creating a custom launcher</source>
        <translation type="vanished">Custom Toolbox è uno strumento utilizzato per creare un lanciatore personalizzato</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">Copyright (c) MX Linux</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">%1 Licenza</translation>
    </message>
    <message>
        <source>%1 Help</source>
        <translation type="vanished">%1 Aiuto</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="774"/>
        <location filename="../src/launchermodel.cpp" line="785"/>
        <source>Could not write file: %1</source>
        <translation>Impossibile scrivere il file: %1</translation>
    </message>
    <message>
        <source>File Removal Error</source>
        <translation type="vanished">Errore di rimozione del file</translation>
    </message>
    <message>
        <location filename="../src/launchermodel.cpp" line="828"/>
        <source>Could not remove file: %1</source>
        <translation>Impossibile rimuovere il file: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="56"/>
        <source>Open List File</source>
        <translation>Apri file elenco</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="58"/>
        <source>List Files (*.list)</source>
        <translation>File elenco (*.list)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="68"/>
        <source>Could not open file. Do you want to try again?</source>
        <translation>Impossibile aprire il file. Vuoi riprovare?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">Licenza</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">Registro delle modifiche</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Annulla</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;Chiudi</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="95"/>
        <source>Custom Toolbox</source>
        <translation type="unfinished">Cassetto degli strumenti personalizzato</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="120"/>
        <source>This app can be used to create custom launchers: box of buttons/icons</source>
        <translation>Questa app può essere utilizzata per creare lanciatori personalizzati: casella di pulsanti/icone</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Don&apos;t show &apos;show this dialog at startup&apos; checkbox</source>
        <translation>Non mostrare la casella di controllo &apos;mostra questa finestra di dialogo all&apos;avvio&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="125"/>
        <source>Full path and name of the .list file you want to load. Supports both custom format (Key=Value) and INI format ([Section]).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sembra che tu sia loggato come root, fai il log out e poi il log in come utente normale per usare questo programma.</translation>
    </message>
</context>
</TS>
