const QString VERSION {"23.6.01"};
